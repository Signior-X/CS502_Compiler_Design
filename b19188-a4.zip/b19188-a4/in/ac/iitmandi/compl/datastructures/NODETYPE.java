/**
 * 
 */
package in.ac.iitmandi.compl.datastructures;

/**
 * @author arjun
 *
 */
public enum NODETYPE {

	STARTNODE {
		
	},
	
	ENDNODE {
		
	},
	
	INTERMEDIATENODE {
		
	},

	RETURNNODE {
			
	},

	PRINTLIVENODE {
			
	}
}
