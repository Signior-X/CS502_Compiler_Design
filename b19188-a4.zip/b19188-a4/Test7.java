class Test2 {
    public static void main(String[] arg) {
        Foobar obj;
        int ret;
        int m_arg;
        m_arg = 10;
        obj = new Foobar();
        ret = obj.Compute(m_arg);
    }
}

class Foobar {
    public int Compute(int num) {
        int t2_1;
        int t2_2;
        int t2_3;
        int t2_4;
        int t2_5;
        int t2_6;
        int t2_7;
        int t2_8;
        int t2_9;
        int t2_10;
        int t2_11;
        int t2_12;
        int t2_13;
        int t2_14;
        int t2_15;
        int t2_16;
        int t2_17;
        int t2_18;
        int t2_19;
        int t2_20;
        int t2_21;
        int t2_22;
        int t2_23;
        int t2_24;
        // OR EXPRESSION
        t2_1 = 10;
        t2_2 = 10;
        t2_3 = 10;
        /* PRINTLIVEVARIABLES */  
        t2_1 = t2_2 || t2_3;
        // AND EXPRESSIO
        t2_4 = 10;
        t2_5 = 10;
        t2_6 = 10;
        /* PRINTLIVEVARIABLES */  
        t2_4 = t2_5 && t2_6;
        // COMPARE EXPRESSION
        t2_7 = 10;
        t2_8 = 10;
        t2_9 = 10;
        /* PRINTLIVEVARIABLES */  
        t2_7 = t2_8 <= t2_9;
        // NEQ EXPRESSION
        t2_10 = 10;
        t2_11 = 10;
        t2_12 = 10;
        /* PRINTLIVEVARIABLES */  
        t2_10 = t2_11 != t2_12;
        // PLUS EXPRESSION
        t2_13 = 10;
        t2_14 = 10;
        t2_15 = 10;
        /* PRINTLIVEVARIABLES */  
        t2_13 = t2_14 + t2_15;
        // MINUS EXPRESSION
        t2_16 = 10;
        t2_17 = 10;
        t2_18 = 10;
        /* PRINTLIVEVARIABLES */  
        t2_16 = t2_17 - t2_18;
        // MULTIPLY EXPRESSION
        t2_19 = 10;
        t2_20 = 10;
        t2_21 = 10;
        /* PRINTLIVEVARIABLES */ 
        t2_19 = t2_20 * t2_21;
        // DIVIDE EXPRESSION
        t2_22 = 10;
        t2_23 = 10;
        t2_24 = 10;
        /* PRINTLIVEVARIABLES */
        t2_22 = t2_23 / t2_24;
        /* PRINTLIVEVARIABLES */
        return t2_1;
    }
}