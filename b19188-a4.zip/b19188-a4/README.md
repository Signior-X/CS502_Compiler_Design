Doubts
1. Same statement will be there or not?
2. Print format?


1. Make some changes to the statement result, so that it will be unique.
DotPrintVisitor mei change karna


// getLastStatement, and use that
// Also use next Statement



// stack for /* PrintLiveVariables */